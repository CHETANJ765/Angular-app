export interface RegisterDetails {
  id: string;
  admittedDate: Date;
  leftOutDate: Date;
  studentName: string;
  studentEmail: string;
  rollNumber: number;
}
